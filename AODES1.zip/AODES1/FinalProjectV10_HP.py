########################################################################################################################################################
# GSP 318 Final Project: Avian Occurrence Data Extraction System
#
# Script to download bird occurrence data from Biodiversity Information Serving Our Nation (BISON) and Global Biodiversity Information 
# Facility (GBIF). GBIF pulls occurrence data from the eBird database, so GBIF data is technically eBird data. This script will allow 
# the user to enter in the common name of a species or the four letter code, a state, and the year in which records should be pulled from. 
# The script searches through the avian database to find the common name and then extracts the scientific name in the correct format for GBIF. 
# There are warnings in place if there are no occurrences found either within the state or for the year. The script then downloads data from the 
# two sources and compiles them into a comma separated values (.csv) file with coordinates and the species scientific name. Duplicates 
# are removed and folders are created for the JSON and CSV files. Duplicate files are removed. The final CSV can be imported into a 
# geographical information system (GIS) of the users choosing. There is additional documentation describing QAQC steps to the user in
# the README text file. Additional questions should be addressed to the creator of this script. 
#
# Author: Holli Pruhsmeier
# Date Script was Started: March 25th, 2020
# Date Script was completed: May 3rd, 2020
# Date Script updated: May 13, 2020. Added in a way to type in the four letter code of the species. Warning messages inserted if the code or the 
# common name was not found in the Avian Dictionary. Additionally, BISON was erroring when no records were returned, so I created a way to pass
# over the code and just use the GBIF data. 
#
# ACKNOWLEDGEMENTS
# Guidance and code advice provided by Jeffrey Kennedy.
# Teaching and inspiration provided by Dr. James Graham.
#
# REFERENCES
# BISON API information located at: https://bison.usgs.gov/doc/api.jsp
# GBIF API information located at: https://www.gbif.org/developer/occurrence
# Ebird owned data from https://ebird.org/home
# Script for folder creation from https://djangocentral.com/check-if-a-directory-exists-if-not-create-it/
# Script for reading and manipulating CSV files from https://www.protechtraining.com/blog/post/python-for-beginners-reading-manipulating-csv-files-737
# Script guide for accessing data on the internet from http://gsp.humboldt.edu/OLM/courses/GSP_318/_Schedule.html
########################################################################################################################################################
# Importing important libraries
import urllib.request         # include the URL library
import json                   # importing the ability to work with json structures
import os                     # importing the operating system
import sys                    # import sys so we can run the program
from PyQt5 import *           # import the main classes and widgets from the Qt library
from PyQt5.QtWidgets import * # imports the widgets from QT
import traceback              # traceback for any errors
import csv                    # imports the csv so we can read the bird name file and get rid of duplicates
########################################################################################################################################################
# Main Dialog box class

try:
    class MainDialogClass(QWidget):
        """
        Function that takes the information from the user, parses the text information, enters
        the information into a URL and extracts the data out to a csv file. 
        """
        def OnButtonPushed(self):
            # grabs the text the user entered in and sets it as different text numbers to be used in later fields
            TheText=self.TheLineEdit.text()
            TheText2=self.TheLineEdit2.text()
            TheText3=self.TheLineEdit3.text()
            #########################################################################################################################
            # This part creates the main folder path names 
            InitialPath = os.path.dirname(os.path.abspath(__file__))  # finds the path of the current file.
            ProjectPath=format(InitialPath)+"\\"                      # adds a \ so that other folders can be created
            #########################################################################################################################
            # This section created a list from the Avian Dictionary and searches for the common name the user entered in
            birdlist=[] # creates a list to place everything from the Avian Dictionary
            # opens the Avian Dictionary and places all the contents into the bird list
            with open(ProjectPath+"AvianDictionary.csv") as CSVfile: 
                reader=csv.reader(CSVfile)
                for row in reader:
                    birdlist.append(row)
            name=TheText                    # sets the first part the user entered in as the name
            #########################################################################################################################
            # This part checks if the name is in the avian dictionary and classes it as the 4 letter code or the full common name.
            print("Finding the scientific name in the Avian Dictionary")
            if len(name)<5:
                col= [x[2] for x in birdlist]
                if name in col:
                    for x in range(2, len(birdlist)):
                        if name==birdlist[x][2]:
                            print(birdlist[x])
                            birdspecies=birdlist[x]
                            print(birdspecies)
                if not name in col: # If the code is not in the avian dictionary, an error will pop up.
                    print("Name not there") 
                    QMessageBox.warning(
                        self, "No 4-Letter Code in Avian Dictionary",
                        "The 4-letter code: "+name+" was not found.\n"
                        "Please check the code you entered in the avian dictionary\n"
                        "and make sure it is correct."
                        )
                    sys.exit(1)                    
            else:            
                col= [x[0] for x in birdlist]   # gives us a list of everything in column 0, which is the common name
                if name in col:                 # grabs the scientific name if the common name is found
                    for x in range(0, len(birdlist)):
                        if name==birdlist[x][0]:
                            print(birdlist[x])
                            birdspecies=birdlist[x]
                            print(birdspecies) 
                if not name in col:  # If the common name is not in the avian dictionary, a code will pop up. 
                    print("Name not there") 
                    QMessageBox.warning(
                        self, "No Common Name Found in the Avian Dictionary",
                        "The common name you entered: "+TheText+" was not found.\n"
                        "Please check the Avian Dictionary to make sure it is\n"
                        "spelled correctly and is all lowercase."
                        )
                    sys.exit(1)                    
            #########################################################################################################################
            # This part splits the scientific name into all of the needed pieces
            birdspec=birdspecies[1]         # selects the whole scientific name
            birdnameparts=birdspec.split()            
             
            Genus=birdnameparts[0]           # selects out the genus of the scientific name
            print(Genus)
            SpecificEpithet=birdnameparts[1] # selects out the specific epithet of the scientific name
            print(SpecificEpithet)
            Discoverer=birdnameparts[2]      # selects out the discoverer
            print(Discoverer)
            CatalogYear=birdnameparts[3]     # selects out the year the species was first recorded
            print(CatalogYear) 
            Year=TheText2                    # selects out the year from the second text box
            print(Year)
            State=TheText3                   # selects out the state from the third text box
            print(State)
            #########################################################################################################################
            # Sets the paths to find the files and creates the folders
            
            MYDIR = (ProjectPath+"JSONFiles")                         # sets up a folder name to hold JSON files
            CHECK_FOLDER = os.path.isdir(MYDIR)                       # checks to see if there is already a folder created

            # If the JSON folder doesn't exist, then create it.
            if not CHECK_FOLDER:
                os.makedirs(MYDIR)                                    # creates the folder
                print("created folder : ", MYDIR)                     # lets you know a folder for JSON Files was created
            
            else:
                print(MYDIR, "folder already exists.")                # informs if there's already a file there
            
            MYDIR2 = (ProjectPath+"CSVFiles")                         # sets a newfolder up for the CSV files
            CHECK_FOLDER = os.path.isdir(MYDIR2)                      # checks to see if there is already a folder created
            
            # If folder doesn't exist, then create it.
            if not CHECK_FOLDER:
                os.makedirs(MYDIR2)                                   # creates the folder
                print("created folder : ", MYDIR2)
            
            else:
                print(MYDIR2, "folder already exists.")               # informs if there's already a file there
            #########################################################################################################################
            # Extracting data from GBIF
            print("Fiding records from GBIF") # informs the user which step it's on
            TheURL="https://api.gbif.org/v1/occurrence/search?year="+Year+"&scientificName="+Genus+"%20"+SpecificEpithet+"%20"+Discoverer+"%20"+CatalogYear+"&stateProvince="+State+"&limit=300"                                 # url with incorporated information from the user
            TheService=urllib.request.urlopen(TheURL)
            TheFile=open(ProjectPath+"JSONFiles\\"+Genus+SpecificEpithet+"GBIF.js","wb")     # write the information as a json file
            TheResponse=TheService.read()   # reading the website's information
            TheFile.write(TheResponse)      # writes to the file the information
            TheFile.close                   # closes the written file    
            # Opening the JSON file for GBIF
            TheFile=open(ProjectPath+"JSONFiles\\"+Genus+SpecificEpithet+"GBIF.js", "r")    
            OriginalString=TheFile.read()                                   # reads the file
            JSOnObject=json.loads(OriginalString)                           # converts into python structure
            PrettyString=json.dumps(JSOnObject,indent=4)                    # loads back into string that looks better   
            #########################################################################################################################
            # Writing GBIF data to a csv
            OutputCSV = ProjectPath+"CSVFiles\\"+Genus+SpecificEpithet+"SpeciesOccurrences.csv" # creates a CSV
            OutputFile=open(OutputCSV, "w")                                                     # writes to the file
            OutputFile.write("Longitude,Latitude,ScientificName,DataType,Source\n")                             # writes the header
            # QAQC check to see if any records are returned. If there aren't then an error message will appear.
            count=JSOnObject["count"]    # locates the count field in the JSON file
            if (count==0):               # if nothing found, a warning box is produced 
                print("nothing here")
                QMessageBox.warning(
                    self, "No Information Returned",
                    "No occurrence data in this state for the "+TheText+".\n"
                    "Please check the range of the species to see if there\n"
                    "are normally occurrences in "+State+"."
                    )
                sys.exit(1)                
            else:                                         # if there are records, the rest of the script occurs. 
                results=JSOnObject["results"]             # find the records field in the JSON file
                # 'For' loop to write GBIF occurrences
                for Occurance in results:
                    TheSpecies = Occurance["species"]     # sets the species field as TheSpecies
                    Lat = Occurance["decimalLatitude"]    # Latitude field set as Lat
                    Long = Occurance["decimalLongitude"]  # Longitude field set as Long
                    RecordType = Occurance["basisOfRecord"]  # Record type to give back observation or musem specimen
                    Collector = Occurance["collectionCode"]  # Data's origin                    
                    OutputFile.write(format(Long)+", "+format(Lat)+", "+format(TheSpecies)+ ", "+format(RecordType)+", "+format(Collector)+"\n")  # writes the information to the CSV
                TheFile.close()
            #########################################################################################################################
            # Importing data from BISON
            print("Finding records from BISON") 
            TheURL="https://bison.usgs.gov/api/search.json?species="+Genus+"%20"+SpecificEpithet+"&type=scientific_name&start=0&count=500&state="+State+"&year="+Year
            TheService=urllib.request.urlopen(TheURL)
            
            TheFile=open(ProjectPath+"JSONFiles\\"+Genus+SpecificEpithet+"BISON.js","wb")     # writes information to a JSON file
            TheResponse2=TheService.read()   # reading the website's information
            TheFile.write(TheResponse2)      # writes to the file the information
            TheFile.close                  
            TheFile2=open(ProjectPath+"JSONFiles\\"+Genus+SpecificEpithet+"BISON.js", "r")    # opening the json file for GBIF
            try:  # Try block in case BISON errors from not producing records. 
                OriginalString2=TheFile2.read()                    # reads the file
                JSOnObject2=json.loads(OriginalString2)           
                PrettyString2=json.dumps(JSOnObject2,indent=4)     # loads back into string that looks better
                #########################################################################################################################
                # Extracting the data from BISON into the CSV
                data=JSOnObject2["data"]   # finds the field data
                # 'For' loop to extract the data
                for Occurrence in data:
                    Provider=Occurrence["provider"]
                    Species=Occurrence["name"]
                    Longitude=Occurrence["decimalLongitude"]
                    Latitude=Occurrence["decimalLatitude"]
                    CommonName=Occurrence["common_name"]
                    RecordType=Occurrence["basis"]
                    OutputFile.write(format(Longitude)+", "+format(Latitude)+", "+format(Species)+", "+format(RecordType)+", "+format(Provider)+"\n")
            except:  # If there is an error, such as if no records are returned, writing the data from BISON will be skipped. 
                print("No records in BISON")
                pass
            
            TheFile2.close()
            OutputFile.close()     
            #########################################################################################################################
            # This section removes duplicates from the CSV file
            print("Removing Duplicates")
            TheFile=open(OutputCSV,"r")           # opening the compiled website data to read
            TheCSVReader=csv.reader(TheFile)
            
            TheNewFile=open(ProjectPath+"CSVFiles\\"+Genus+SpecificEpithet+"XYtogether.csv","w") # writes to a new file
            TheNewFile.write("LongitudeLatitude,ScientificName,DataType,Source\n")  # combined longitude and latitude
            NumRows=0
            for TheRow in TheCSVReader:    # runs through all the columns to write them in a combined format
                if (NumRows>0):            # Looks beyond the header
                    Longitude=TheRow[0]                                
                    Longitude=format(Longitude)  
                    Latitude=TheRow[1]                           
                    Latitude=format(Latitude)
                    ScientificName=TheRow[2]
                    ScientificName=format(ScientificName)
                    DataType=TheRow[3]
                    DataType=format(DataType)
                    Source=TheRow[4]
                    Source=format(Source)
                    
                    TheNewFile.write(Longitude+" "+Latitude+","+ScientificName+","+DataType+","+Source+"\n") # combines the coordinates with a space
                NumRows+=1  #goes down a row
            
            TheFile.close()
            TheNewFile.close()
            
            # Writing a dictionary to remove the duplicates
            Therows = open(ProjectPath+"CSVFiles\\"+Genus+SpecificEpithet+"XYtogether.csv", "r")
            TheCSVReader=csv.reader(Therows)
            TheNewFile=open(ProjectPath+"CSVFiles\\"+Genus+SpecificEpithet+"DuplicatesRemoved.csv","w") # writes to a new file
            newrows = []
            for row in Therows:
                if row not in newrows:    # if the row is not already there, then the row is appended to the dictionary
                    newrows.append(row)
                    TheNewFile.write(row) # writes the entries that have the duplicates removed into the new file
            
            TheNewFile.close()
            Therows.close()
            
            # Bringing in the csv file to separate longitude and latitude again
            TheFile = open(ProjectPath+"CSVFiles\\"+Genus+SpecificEpithet+"DuplicatesRemoved.csv", "r") 
            TheCSVReader=csv.reader(TheFile)
            TheFinalFile=open(ProjectPath+"CSVFiles\\"+TheText+"_"+State+"_"+Year+"Records.csv","w") # writes to a new file
            TheFinalFile.write("Longitude,Latitude,Species,ScientificName,DataType,Source\n") # header to separate longitude and latitude
            
            NumRows=0
            for TheRow in TheCSVReader:
                if (NumRows>0):                # Looks beyond the header
                    Parts=TheRow[0]            # takes the first column
                    SplitParts=Parts.split()   # splits the first column
                    Longitude=SplitParts[0]    # separates longitude
                    Latitude=SplitParts[1]     # separates latitude
                    ScientificName=TheRow[1]
                    ScientificName=format(ScientificName)
                    DataType=TheRow[2]
                    DataType=format(DataType)
                    Source=TheRow[3]
                    Source=format(Source)                    
                    TheFinalFile.write(Longitude+","+Latitude+","+TheText+","+ScientificName+","+DataType+","+Source+"\n") # rewritten for separate coordinates
                NumRows+=1  #goes down a row
                
            TheFile.close()
            TheFinalFile.close()
            print("Final CSV written")
            
            # Removes the extra CSVs to prevent confusion for the user
            os.remove(ProjectPath+"CSVFiles\\"+Genus+SpecificEpithet+"DuplicatesRemoved.csv")
            os.remove(ProjectPath+"CSVFiles\\"+Genus+SpecificEpithet+"XYtogether.csv")
            os.remove(OutputCSV)
            print("Extra files removed")
            
            #########################################################################################################################
            # This talks back to the GUI to let the user know when the data is done being extracted
            self.OutputLabel2.setText("Data extracted! Check the CSV folder where the AODES1 script is held!") # tells the GUI when the data is extracted
        def __init__(self):
            super().__init__()
                
            # Main Layout that will contain the horizontal ones
            MainLayout = QVBoxLayout()
            self.setLayout(MainLayout)  # add the layout to the main dialog object
            
            # Text layout
            HorizontalLayout0=QHBoxLayout() 
            MainLayout.addLayout(HorizontalLayout0)     
            HorizontalLayout1=QHBoxLayout() 
            MainLayout.addLayout(HorizontalLayout1)
            HorizontalLayout2=QHBoxLayout()
            MainLayout.addLayout(HorizontalLayout2) 
            HorizontalLayout3=QHBoxLayout()
            MainLayout.addLayout(HorizontalLayout3) 
            HorizontalLayout4=QHBoxLayout()
            MainLayout.addLayout(HorizontalLayout4) 
            HorizontalLayout5=QHBoxLayout()
            MainLayout.addLayout(HorizontalLayout5) 
            HorizontalLayout6=QHBoxLayout()
            MainLayout.addLayout(HorizontalLayout6)     
            HorizontalLayout7=QHBoxLayout()
            MainLayout.addLayout(HorizontalLayout7) 
            HorizontalLayout8=QHBoxLayout()
            MainLayout.addLayout(HorizontalLayout8)             
            #########################################################################################################################
            # Main layout that explains what the user should enter in. 
            TheMainLabel = QLabel("Welcome to the Avian Occurrence Data Extraction System Version 1!")
            TheMainLabel.setStyleSheet("font: bold 15pt Adobe Heiti Std R; background-color: lightgreen; border: 2px solid darkgreen; padding: 4px")
                                                                       
            HorizontalLayout0.addWidget(TheMainLabel) # add the label        
            #########################################################################################################################
            # Section 1- Explains important user information 
            DescriptionLabel11 = QLabel("This system allows you to type in the common name of an avian species or the 4-letter code, the year, and the state that you wish")
            DescriptionLabel11.setStyleSheet("font: 12pt Times New Roman")
            HorizontalLayout1.addWidget(DescriptionLabel11) # add the label             
            #########################################################################################################################
            # Section 2- Explains the rest to the user
            DescriptionLabel2 = QLabel("to extract data for. Extracted data will contain longitude and latitude coordinates along with the scientific name of the species.")
            DescriptionLabel2.setStyleSheet("font: 12pt Times New Roman")
            HorizontalLayout2.addWidget(DescriptionLabel2) # add the label             
            #########################################################################################################################
            # Section 3- Explains the rest to the user
            DescriptionLabel31 = QLabel("Wherever you store the Python script, two folders will be created: one to hold the JSON files and one to hold the CSV files that you can")
            DescriptionLabel31.setStyleSheet("font: 12pt Times New Roman")
            HorizontalLayout3.addWidget(DescriptionLabel31) # add the label             
            #########################################################################################################################
            # Section 4- Guides to have the user use the full name from GBIF
            DescriptionLabel = QLabel("import into a geographical information system (GIS) for analysis. All coordinates are in WGS 1984.")
            DescriptionLabel.setStyleSheet("font: 12pt Times New Roman")
            HorizontalLayout4.addWidget(DescriptionLabel) # add the label  
            #########################################################################################################################
            # Section 5- Collects the information about the scientific name
            Description5Label = QLabel("Avian Common Name or 4-Letter Code")
            Description5Label.setStyleSheet("font: 12pt Times New Roman")
            HorizontalLayout5.addWidget(Description5Label) # add the label
            self.TheLineEdit = QLineEdit(self)
            HorizontalLayout5.addWidget(self.TheLineEdit)
            Description51Label = QLabel("Example: RWBL or red-winged blackbird")
            Description51Label.setStyleSheet("font: 12pt Times New Roman")
            HorizontalLayout5.addWidget(Description51Label) # add the label            
            #########################################################################################################################
            # Section 6-Collects the information about the year
            Description61Label = QLabel("Year of Observations")
            Description61Label.setStyleSheet("font: 12pt Times New Roman")
            HorizontalLayout6.addWidget(Description61Label)   # add the label 
            self.TheLineEdit2 = QLineEdit(self)               # widget that collects information from the user
            HorizontalLayout6.addWidget(self.TheLineEdit2)
            Description62Label = QLabel("Example: 2010")
            Description62Label.setStyleSheet("font: 12pt Times New Roman")
            HorizontalLayout6.addWidget(Description62Label)   # add the label             
            #########################################################################################################################
            # Section 7-Collects the information about the State
            Description71Label = QLabel("State in the U.S.")
            Description71Label.setStyleSheet("font: 12pt Times New Roman")
            HorizontalLayout7.addWidget(Description71Label) # add the label             
            self.TheLineEdit3 = QLineEdit(self)
            HorizontalLayout7.addWidget(self.TheLineEdit3)
            Description72Label = QLabel("Example: NewYork")
            Description72Label.setStyleSheet("font: 12pt Times New Roman")
            HorizontalLayout7.addWidget(Description72Label) # add the label             
            #########################################################################################################################
            # Section 8- Push Button to process the inserted information
            TheButton=QPushButton("Extract Data!") # create the button and give it a text label
            TheButton.setStyleSheet("QPushButton { background-color: lightgreen; border-style: outset; border-width: 2px; border-radius: 10px; border-color: darkgreen; font: bold 14px Adobe Heiti Std R ; padding: 5px} QPushButton:pressed { background-color: red }")            
            HorizontalLayout8.addWidget(TheButton) # add the button to the layout
            TheButton.clicked.connect(self.OnButtonPushed) # add this line to connect the button to a function 
            self.OutputLabel2 = QLabel("") # start with this being blank
            HorizontalLayout8.addWidget(self.OutputLabel2) # add the label   
                       
            #########################################################################################################################
            # setup the size of the window
            self.setGeometry(200, 100, 700, 300) # x, y, width, height, in pixels
            self.setWindowTitle("AODES1: Avian Occurrence Data Extraction System Version 1") # title appears in the top bar of the dialog box
              
            self.show() # display the dialog to the user
    
    ##################################################################################################################################
    # Create the app and the dialog box and then run the app until the user closes the dialog
    TheApplicationObject = QApplication(sys.argv)
    TheApplicationObject.setStyle('Fusion') # sets the style
    MainDialogObject = MainDialogClass()
    
    
    sys.exit(TheApplicationObject.exec_())
######################################################################################################################################
except Exception  as TheException:   # exception if there is an error somewhere in the script
    print("Sorry, an error has occurred: "+format(TheException))
    exc_type, exc_value, exc_traceback =sys.exc_info()
    print(exc_type)
    print(exc_value)
    traceback.print_tb(exc_traceback, limit=10)    
######################################################################################################################################