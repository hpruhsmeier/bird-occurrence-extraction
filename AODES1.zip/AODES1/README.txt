Welcome to Avian Occurrence Data Extraction System Version 1


TABLE OF CONTENTS
I. Introduction
II. Purpose of the Script
III. Intellectual Property Rights
IV. Installation Instructions
V. Running AODES1
VI. Quality Assurance Quality Check
VII. Contacts
VIII. Citing Sources
IX. Species List

----------------------------------------------------------------------------------------------------------------------------------------

I. INTRODUCTION

Thank you for choosing to extract data using the Avian Occurrence Data Extraction System Version 1 (AODES1). 
This walkthrough will guide you to easily and effortlessly extract data from several biological information websites 
such as Biodiversity Information Serving Our Nation (BISON), eBird, and Global Biodiversity Information Facility (GBIF). 
AODES1 handles records on 840 species that consist of: ducks, geese, waterfowl, New World quail, pheasants, grouse, 
flamingos, grebes, sandgrouse, pigeons, doves, cuckoos, nightjars, nighthawks, poorwills, swifts, hummingbirds, rails, 
gallinules, coots, limpkin, cranes, thick-knees, stilts, avocets, loons, cormorants, oystercatchers, lapwings, plovers, sandpipers, 
godwits, phalaropes, auks, murres, puffins, gulls, terns, skimmers, loons, albatrosses, storm-petrels, shearwaters, petrels, 
storks, frigatebirds, boobies, ganets, cormorants, anhinga, pelicans, herons, bitterns, egrets, ibis, spoonbills, New World vultures, 
osprey, hawks, eagles, kites, owls, kingfishers, woodpeckers, sapsuckers, falcons, kestrels, flycatchers, shrikes, vireos, crows, 
ravens, larks, swallows, martins, chickadees, titmice, wrens, gnatcatchers, kinglets, warblers, thrushes, mockingbirds, waxwings, 
sparrows, finches, and tanagers. 

After using this program, you should have occurrence records for a species with latitude and longitude coordinates in WGS 1984, 
the species scientific name, the data collection type, and the data provider. These occurrence records will be in a comma separated 
values (CSV) file that can be imported into a geographical information system. Please refer to section IV. Installation Instructions and
VI. Quality Assurance Quality Check  to ensure that you get the results you are looking for.

----------------------------------------------------------------------------------------------------------------------------------------

II. PURPOSE OF THE SCRIPT

This script's purpose is to assist in the collection and quality assurance of avian occurrence records from biological websites. 

----------------------------------------------------------------------------------------------------------------------------------------

III. INTELLECTUAL PROPERTY RIGHTS

This script is an open source liscence for anyone to use. Make sure you give credit to BISON, GBIF, and eBird for their data. Please refer
to section VIII. Citing Sources for more information about how to cite these sources. 

----------------------------------------------------------------------------------------------------------------------------------------

IV. INSTALLATION INSTRUCTIONS

1. After you have downloaded unzipped the file, make sure there is the main AODES1.py script and AvianDictionary.csv  
2. Place the Python script and the CSV together into a folder. Make sure these two files remain together for the script to work. 
3. Make sure the following software is downloaded onto your computer: Python, WingIDE, PYQT5. 
4. Open WingIDE. In WingIDE, open the main AODES1 Python script.
5. Once the AODES1 script is open in WingIDE, click the green start triangle to run the script. You should see a window that appears
that says "Welcome to the Avan Occurrence Data Extraction System Version 1!". If this appears, then the code worked and you can 
start extracting data!

----------------------------------------------------------------------------------------------------------------------------------------

V. RUNNING AODES1

1. In the first AODES1 text box, type the common name of a species. Do not capitalize any letters to ensure the record is in the Avian
Dictionary. Please include any other symbols that are normally included in the common name. Two examples are: yellow-rumped warbler;
townsend's warbler. 
2. In the second text box, enter in the desired year you want observation records for. Example: 1995
3. In the third text box, enter in the desired state in the U.S. you want records for. If you have a state that contains two words, do not 
include a space. Keep them as one word with the starting letters capitalized. (Example: NewYork). 
4. Click the �Extract Data!� button to begin the data extraction. 
5. Once your data has been extracted, words next to the button will appear saying �Data extracted! Check the CSV folder where the 
AODES1 script is kept". 
6. Where you stored the AODES1 python file, there will be two new folders created that say "JSONFiles" and "CSVFiles". Open the 
created CSVFiles folder and there will be the CSVs for each species you extract data for. These CSVs will contain less than 800 
occurrence records because there is an internal quality check function that removes duplicated records. 

---------------------------------------------------------------------------------------------------------------------------------------- 

VI. QUALITY ASSURANCE QUALITY CHECK (QAQC)

To ensure you are receiving quality data, follow these steps to perform your own quality check. 

Before you export data:
1. Do you know where you species of interest normally occurs? Visit Cornell's Lab at https://www.allaboutbirds.org/guide/search  
and type in the species of interest. Be sure to make a note of their ranges during the winter and during the summer. If you type in a state
that the species does not occur in, an error message will appear informing you to check which states the species normally occurs in. 
2. Are you properly spelling the species name or the 4-letter code? There are some species that are very close in their names, so it is 
important to know which species you are actually wanting to obtain records for. For example, yellow warbler and yellow-rumped warbler. 
If you are not sure how to exactly spell the species name (including dashes or apostrophes), then look up the species name to get the exact 
spelling or search through the Species List. Make sure that there are no capitalized letters for the common name and all capitals for the 
4-letter code when you type it into AODES1. 
3. Do you know if that species is in the state you are trying to obtain records for? Some species only occur in some states, such is the case
with Hawaii where there are certain endemic species that only occur in that area. Note: AODES1 is used for common species. 
4. Is the species you're looking for not on the species list? This data extraction system is limited to only 430 species. If you are looking for
another species that is not on the list, please visit: https://bison.usgs.gov/#home and extract data from here. 

While data is exporting:
1. AODES1 checks to see if the common name or the 4-letter code is in the AvianDctionary. If it is not, an error message will appear. 
2. AODES1 checks in the records to see if that species has occurrence records in the state you are searching. If there are no occurrence records
in that state, an error message box will appear. After it quite you from the script, please refer back to https://www.allaboutbirds.org/guide/search  
to check where that species normally occurs.
3. Some species may not have records in BISON, so a way to passover those records was implemented in the code. 
4. AODES1 performs its own QAQC after it exports data to remove duplicated records that could cause issues. 

After you export data:
1. Open the CSV and take a quick look through the coordinates. If any have less than 2 decimal places, consider deleting those records due 
to potential uncertainty from innacurate coordinates. 
2. After bring imported into a geographic information system (GIS), do the occurrences populate the frame? If not, remember that the 
occurrence records are in WGS 1984, so if you have other shape or raster files in the GIS, you may need to project the occurrence records to 
match the projection of the rest of your data files. 
3. After being brought into a GIS, do the occurrences of the match where the species normally occurs?
4. These records are only for the full year and there currently is not a way to search by a specific date. Please refer to the GBIF and BISON 
websites to extract data if you are searching for a specific time frame of occurrences. 

----------------------------------------------------------------------------------------------------------------------------------------

VII. CONTACTS

If you are having issues or want to know how to use AODES1, contact Holli Pruhsmeier at holli.pruhsmeier@gmail.com. 
In the email, provide your name, a description of your question or issue with AODES1, and the best way to reach you. 

----------------------------------------------------------------------------------------------------------------------------------------

VIII. CITING SOURCES

It is important to acknowledge each of the dataset providers. Please use the following citation references from BISON and GBIF. 

BISON - Use the following format to cite data retrieved from BISON or refer to their website at https://bison.usgs.gov/doc/api.jsp

[Data Provider or owner name]. [Resource or Dataset Name] published by [Data Provider name, address or affiliation(s)] 
(Accessed through Biodiversity Information Serving Our Nation (BISON), https://bison.usgs.gov, YYYY-MM-DD)

For example:
USGS. Occurrences for the Yellow-Rumped Warbler published by Biodiversity Information Serving Our Nation.  (Accessed through 
Biodiversity Information Serving Our Nation (BISON), https://bison.usgs.gov, 2007-02-22)

GBIF -  Use the following format to cite data retrieved from GBIF or refer to their website at https://www.gbif.org/citation-guidelines

[Data Provider or owner name]. [Resource or Dataset Name] published by [Data Provider name, address or affiliation(s)]. Occurrence 
download accessed via GBIF.org on YYYY-MM-DD.

For example:
eBird Basic Dataset. Version: EBD_relMay-2017. Cornell Lab of Ornithology, Ithaca, New York. May 2017. Occurrence download 
accessed via GBIF.org on 2020-08-06.

----------------------------------------------------------------------------------------------------------------------------------------

IX. SPECIES LIST

Listed are all of the species in the Avian Dictionary. Ctrl+f to open the find tool and search for your species of interest. 

CommonName		ScientificName			4-Letter Code
abert's towhee		Melozone aberti�(S.F.Baird, 1852)		ABTO
acadian flycatcher		Empidonax virescens (Vieillot, 1818)	ACFL
acorn woodpecker		Melanerpes formicivorus (Swainson, 1827)	ACWO
alder flycatcher		Empidonax alnorum Brewster, 1895	ALFL
aleutian tern		Onychoprion aleuticus�(S.F.Baird, 1869)	ALTE
allen's hummingbird		Selasphorus sasin�(Lesson, 1829)		ALHU
altamira oriole		Icterus gularis�(Wagler, 1829)		ALOR
amazon kingfisher		Chloroceryle amazona (Latham, 1790)	AMKI
american avocet		Recurvirostra americana�Gmelin, 1789	AMAV
american bittern		Botaurus lentiginosus�(Rackett, 1813)	AMBI
american black duck		Anas rubripes�Brewster, 1902		ABDU
american crow		Corvus brachyrhynchos C.L.Brehm, 1822	AMCR
american dipper		Cinclus mexicanus�Swainson, 1827		AMDI
american flamingo		Phoenicopterus ruber�Linnaeus, 1758	AMFL
american goldfinch		Spinus tristis�(Linnaeus, 1758)		AMGO
american kestrel		Falco sparverius Linnaeus, 1758		MAKE
american oystercatcher		Haematopus palliatus�Temminck, 1820	AMOY
american pipit		Anthus rubescens�(Tunstall, 1771)		AMPI
american redstart		Setophaga ruticilla�(Linnaeus, 1758)	AMRE
american robin		Turdus migratorius Linnaeus, 1766		AMRO
american three-toed woodpecker	Picoides dorsalis�S.F.Baird, 1858		ATTW
american tree sparrow		Spizella arborea�(A.Wilson, 1810)		ATSP
american white pelican		Pelecanus erythrorhynchos Gmelin, 1789	AWPE
american wigeon		Mareca americana�(Gmelin, 1789)		AMWI
american woodcock		Scolopax minor�Gmelin, 1789		AMWO
ancient murrelet		Synthliboramphus antiquus�(Gmelin, 1789)	ANMU
anhinga			Anhinga anhinga�(Linnaeus, 1766)		ANHI
anna's hummingbird		Calypte anna�(Lesson, 1829)		ANHU
antillean nighthawk		Chordeiles gundlachii�Lawrence, 1857	ANNI
antillean palm-swift		Tachornis phoenicobia�Gosse, 1847	ANPS
aplomado falcon		Falco femoralis�Temminck, 1822		APFA
arctic loon			Gavia arctica�(Linnaeus, 1758)		ARLO
arctic tern			Sterna paradisaea�Pontoppidan, 1763	ARTE
arctic warbler		Phylloscopus borealis�(J.H.Blasius, 1858)	ARWA
arizona woodpecker		Picoides arizonae�(Hargitt, 1886)		ARWO
ash-throated flycatcher		Myiarchus cinerascens (Lawrence, 1851)	ATFL
ashy storm-petrel		Oceanodroma homochroa�(Coues, 1864)	ASSP
atlantic puffin		Fratercula arctica�(Linnaeus, 1758)		ATPU
audubon's oriole		Icterus graduacauda�Lesson, 1839		AUOR
audubon's shearwater		Puffinus lherminieri�Lesson, 1839		AUSH
aztec thrush			Ridgwayia pinicola�(P.L.Sclater, 1859)	AZTH
bachman's sparrow		Peucaea aestivalis�(M.H.K.Lichtenstein, 1823)	BACS
bahama mockingbird		Mimus gundlachii�Cabanis, 1855		BAMO
baikal teal			Sibirionetta formosa�(Georgi, 1775)	BATE
baird's sandpiper		Calidris bairdii�(Coues, 1861)		BASA
baird's sparrow		Ammodramus bairdii�(Audubon, 1844)	BAIS
bald eagle			Haliaeetus leucocephalus�(Linnaeus, 1766)	BAEA
baltimore oriole		Icterus galbula�(Linnaeus, 1758)		BAOR
bananaquit			Coereba flaveola�(Linnaeus, 1758)		BANA
band-tailed pigeon		Patagioenas fasciata�(Say, 1823)		BTPI
bank swallow		Riparia riparia (Linnaeus, 1758)		BANS
bar-tailed godwit		Limosa lapponica�(Linnaeus, 1758)		BTGO
barn owl			Tyto alba�(Scopoli, 1769)		BANO
barn swallow		Hirundo rustica Linnaeus, 1758		BARS
barnacle goose		Branta leucopsis�(Bechstein, 1803)		BARG
barred owl			Strix varia Barton, 1799		BADO
barrow's goldeneye		Bucephala islandica�(Gmelin, 1789)		BAGO
bay-breasted warbler		Setophaga castanea�(A.Wilson, 1810)	BBWA
bell's vireo			Vireo bellii Audubon, 1844		BEVI
belted kingfisher		Megaceryle alcyon (Linnaeus, 1758)	BEKI
bendire's thrasher		Toxostoma bendirei�(Coues, 1873)		BETH
berylline hummingbird		Amazilia beryllina�(Deppe, 1830)		BEHU
bewick's wren		Thryomanes bewickii (Audubon, 1827)	BEWR
bicknell's thrush		Catharus bicknelli�(Ridgway, 1882)		BITH
black francolin		Francolinus francolinus�(Linnaeus, 1766)	BLFR
black guillemot		Cepphus grylle�(Linnaeus, 1758)		BLGU
black noddy		Anous stolidus�(Linnaeus, 1758)		BLNO
black oystercatcher		Haematopus bachmani�Audubon, 1838	BLOY
black kite			Milvus migrans (Boddaert, 1783)		BLAK
black phoebe		Sayornis nigricans (Swainson, 1827)	BLPH
black rail			Laterallus jamaicensis�(Gmelin, 1789)	BLRA
black rosy-finch		Leucosticte atrata�Ridgway, 1874		BLRF
black scoter		Melanitta americana�(Swainson, 1832)	BLSC
black skimmer		Rynchops niger�Linnaeus, 1758		BLSK
black storm-petrel		Oceanodroma melania�(Bonaparte, 1854)	BLSP
black swan			Cygnus atratus�(Latham, 1790)		BLSW
black swift			Cypseloides niger�(Gmelin, 1789)		BLSW
black tern			Chlidonias nigra�(Linnaeus, 1758)		BLTE
black turnstone		Arenaria melanocephala�(Vigors, 1829)	BLTU
black vulture		Coragyps atratus (Bechstein, 1793)		BLVU
black-and-white warbler	Mniotilta varia�(Linnaeus, 1766)		BAWW
black-backed woodpecker	Picoides arcticus (Swainson, 1832)		BBWO
black-bellied plover		Pluvialis squatarola�(Linnaeus, 1758)	BBPL
black-bellied whistling-duck	Dendrocygna autumnalis�(Linnaeus, 1758)	BBWD
black-billed cuckoo		Coccyzus erythropthalmus�(A.Wilson, 1811)	BBCU
black-billed magpie		Pica hudsonia (Sabine, 1823)		BBMA
black-capped chickadee	Poecile atricapillus (Linnaeus, 1766)	BCCH
black-capped gnatcatcher	Polioptila nigriceps S.F.Baird, 1864		BCGN
black-capped petrel		Pterodroma hasitata�(Kuhl, 1820)		BCPE
black-capped vireo		Vireo atricapilla Woodhouse, 1852		BCVI
black-chinned sparrow		Spizella atrogularis (Cabanis, 1851)		BCSP
black-crested titmouse		Baeolophus atricristatus (Cassin, 1850)	BCTI
black-crowned night-heron	Nycticorax nycticorax (Linnaeus, 1758)	BCNH
black-faced grassquit		Tiaris bicolor�(Linnaeus, 1766)		BFGR
black-footed albatross		Phoebastria nigripes�(Audubon, 1839)	BFAL
black-headed grosbeak		Pheucticus melanocephalus (Swainson, 1827)	BHGR
black-headed gull		Chroicocephalus ridibundus�(Linnaeus, 1766)	BHGU
black-legged kittiwake		Rissa tridactyla�(Linnaeus, 1758)		BLKI
black-necked stilt		Himantopus mexicanus�(Statius Muller, 1776)	BNST
black-tailed gnatcatcher	Polioptila melanura Lawrence, 1857	BTGN
black-tailed godwit		Limosa limosa�(Linnaeus, 1758)		BLTG
black-tailed gull		Larus crassirostris�Vieillot, 1818		BTGU
black-throated blue warbler	Setophaga caerulescens�(J.F.Gmelin, 1789)	BTBW
black-throated grey warbler	Setophaga nigrescens (J.K.Townsend, 1837)	BTYW
black-throated green warbler	Setophaga virens�(J.F.Gmelin, 1789)	BTNW
black-throated sparrow		Amphispiza bilineata (Cassin, 1850)	BTSP
black-vented oriole		Icterus wagleri�P.L.Sclater, 1857		BVOR
black-vented shearwater	Puffinus opisthomelas�Coues, 1864		BVSH
black-whiskered vireo		Vireo altiloquus (Vieillot, 1808)		BWVI
blackburnian warbler		Setophaga fusca�(Statius M�ller, 1776)	BLBW
blackpoll warbler		Setophaga striata�(J.R.Forster, 1772)	BLPW
blue bunting		Cyanocompsa parellina�(Bonaparte, 1850)	BLBU
blue grosbeak		Passerina caerulea�(Linnaeus, 1758)	BLGR
black-winged stilt		Himantopus himantopus�(Linnaeus, 1758)	BWST
blue jay			Cyanocitta cristata (Linnaeus, 1758)	BLJA
blue mockingbird		Melanotis caerulescens (Swainson, 1827)	BLMO
blue-footed booby		Sula nebouxii�Milne-Edwards, 1882	BFBO
blue-gray gnatcatcher		Polioptila caerulea (Linnaeus, 1766)	BGGN
blue-headed vireo		Vireo solitarius (A.Wilson, 1810)		BHVI
blue-throated mountain-gem	Lampornis clemenciae�(Lesson, 1829)	BTMG
blue-winged teal		Spatula discors�(Linnaeus, 1766)		BWTE
blue-winged warbler		Vermivora chrysoptera�(Linnaeus, 1766)	BWWA
bluethroat			Cyanecula svecica�(Linnaeus, 1758)	BLUE
boat-tailed grackle		Quiscalus major�Vieillot, 1819		BTGR
bobolink			Dolichonyx oryzivorus�(Linnaeus, 1758)	BOBO
bohemian waxwing		Bombycilla garrulus (Linnaeus, 1758)	BOWA
bonaparte's gull		Chroicocephalus philadelphia�(Ord, 1815)	BOGU
boreal chickadee		Poecile hudsonicus�(J.R.Forster, 1772)	BOCH
boreal owl			Aegolius funereus (Linnaeus, 1758)		BOOW
botteri's sparrow		Peucaea botterii�(P.L.Sclater, 1858)	BOSP
brambling			Fringilla montifringilla�Linnaeus, 1758	BRAM
brandt's cormorant		Phalacrocorax penicillatus�(Brandt, 1837)	BRAC
brant			Branta bernicla�(Linnaeus, 1758)		BRAN
brewer's blackbird		Euphagus cyanocephalus (Wagler, 1829)	BRBL
brewer's sparrow		Spizella breweri�Cassin, 1856	BRSP
bridled tern			Onychoprion anaethetus�(Scopoli, 1786)	BRTE
bridled titmouse		Baeolophus wollweberi (Bonaparte, 1850)	BRTI
bristle-thighed curlew		Numenius tahitiensis�(Gmelin, 1789)	BTCU
broad-billed hummingbird	Cynanthus latirostris�Swainson, 1827	BBIH
broad-tailed hummingbird	Selasphorus platycercus�(Swainson, 1827)	BTHU
broad-winged hawk		Buteo platypterus�(Vieillot, 1823)		BWHA
bronzed cowbird		Molothrus aeneus�(Wagler, 1829)		BROC
brown booby		Sula leucogaster�(Boddaert, 1783)		BRBO
brown creeper		Certhia americana Bonaparte, 1838	BRCR
brown jay			Psilorhinus morio�(Wagler, 1829)		BRJA
brown noddy		Anous stolidus�(Linnaeus, 1758)		BRNO
brown pelican		Pelecanus occidentalis Linnaeus, 1766	BRPE
brown shrike		Lanius cristatus Linnaeus, 1758		BROS
brown thrasher		Toxostoma rufum�(Linnaeus, 1758)		BRTH
brown-capped rosy-finch	Leucosticte australis�Ridgway, 1874	BCRF
brown-crested flycatcher	Myiarchus tyrannulus�(Statius Muller, 1776)	BCFL
brown-headed cowbird		Molothrus ater�(Boddaert, 1783)		BHCO
brown-headed nuthatch		Sitta pusilla Latham, 1790		BHNU
budgerigar			Melopsittacus undulatus�(Shaw, 1805)	BUDG
buff-bellied hummingbird	Amazilia yucatanensis�(Cabot, 1845)	BBEH
buff-breasted flycatcher		Empidonax fulvifrons�(Giraud, 1841)	BBFL
buff-breasted sandpiper	Calidris subruficollis�(Vieillot, 1819)		BBSA
buff-collared nightjar		Antrostomus ridgwayi�Nelson, 1897	BCNI
bufflehead			Bucephala albeola�(Linnaeus, 1758)	BUFF
buller's shearwater		Ardenna bulleri�(Salvin, 1888)		BULS
bullock's oriole		Icterus bullockii�(Swainson, 1827)		BUOR
burrowing owl		Athene cunicularia (Molina, 1782)		BUOW
bushtit			Psaltriparus minimus (J.K.Townsend, 1837)	BUSH
cackling goose		Branta hutchinsii�(Richardson, 1832)	CACG
cactus wren		Campylorhynchus brunneicapillus (Lafresnaye, 1835) CACW
california condor		Gymnogyps californianus (Shaw, 1797)	CACO
california gnatcatcher		Polioptila californica Brewster, 1881	CAGN
california gull		Larus californicus�Lawrence, 1854		CAGU
california quail		Callipepla californica�(Shaw, 1798)		CAQU
california scrub-jay		Aphelocoma californica (Vigors, 1839)	CASJ
california thrasher		Toxostoma redivivum�(Gambel, 1845)	CATH
california towhee		Melozone crissalis�(Vigors, 1839)		CALT
canada goose		Branta canadensis�(Linnaeus, 1758)	CANG
canada jay			Perisoreus canadensis (Linnaeus, 1766)	CAJA
canada warbler		Cardellina canadensis�(Linnaeus, 1766)	CAWA
canvasback			Aythya valisineria�(A.Wilson, 1814)		CANV
canyon towhee		Melozone fusca�(Swainson, 1827)		CANT
canyon wren		Catherpes mexicanus (Swainson, 1829)	CANW
cape may warbler		Setophaga tigrina�(J.F.Gmelin, 1789)	CMWA
carolina chickadee		Poecile carolinensis (Audubon, 1834)	CACH
carolina wren		Thryothorus ludovicianus (Latham, 1790)	CARW
caspian tern		Hydroprogne caspia�(Pallas, 1770)		CATE
cassia crossbill		Loxia curvirostra�Linnaeus, 1758		CACR
cassin's auklet		Ptychoramphus aleuticus�(Pallas, 1811)	CAAU
cassin's finch		Haemorhous cassinii (S.F.Baird, 1854)	CAFI
cassin's kingbird		Tyrannus vociferans�Swainson, 1826	CAKI
cassin's sparrow		Peucaea cassinii (Woodhouse, 1852)	CASP
cattle egret			Bubulcus ibis (Linnaeus, 1758)		CAEG
cave swallow		Petrochelidon fulva (Vieillot, 1808)		CASW
cedar waxwing		Bombycilla cedrorum Vieillot, 1808		CEDW
cerulean warbler		Setophaga cerulea�(A.Wilson, 1810)	CERW
chestnut-backed chickadee	Poecile rufescens (J.K.Townsend, 1837)	CBCH
chestnut-bellied sandgrouse	Pterocles exustus�Temminck, 1825		CBSA
chestnut-collared longspur	Calcarius ornatus�(J.K.Townsend, 1837)	CCLO
chestnut-sided warbler		Setophaga pensylvanica�(Linnaeus, 1766)	CSWA
chihuahuan raven		Corvus cryptoleucus Couch, 1854		CHRA
chimney swift		Chaetura pelagica�(Linnaeus, 1758)		CHSW
chinese egret		Egretta eulophotes (Swinhoe, 1860)	CHEG
chinese pond-heron		Ardeola bacchus (Bonaparte, 1855)	CHPH
chinese sparrowhawk		Accipiter soloensis (Horsfield, 1821)	CHIS
chipping sparrow		Spizella passerina (Bechstein, 1798)	CHSP
chuck-will's-widow		Antrostomus carolinensis�(J.F.Gmelin, 1789)	CWWI
chukar			Alectoris chukar�(J.E.Gray, 1830)		CHUK
cinnamon hummingbird		Amazilia rutila�(Delattre, 1843)		CIHU
cinnamon teal		Spatula cyanoptera�(Vieillot, 1816)		CITE
clapper rail			Rallus crepitans�Gmelin, 1789		CLRA
clark's grebe		Aechmophorus clarkii�(Lawrence, 1858)	CLGR
clark's nutcracker		Nucifraga columbiana (A.Wilson, 1811)	CLNU
clay-colored sparrow		Spizella pallida�(Swainson, 1832)		CCSP
clay-colored thrush		Turdus grayi Bonaparte, 1838		CCTH
cliff swallow		Petrochelidon pyrrhonota (Vieillot, 1817)	CLSW
collared forest-falcon		Micrastur semitorquatus (Vieillot, 1817)	COFF
common black hawk		Buteogallus anthracinus (Deppe, 1830)	COBH
common crane		Grus grus�(Linnaeus, 1758)		CCRA
common cuckoo		Cuculus canorus�Linnaeus, 1758		COCC
common eider		Somateria mollissima�(Linnaeus, 1758)	COEI
common gallinule		Gallinula galeata�(Lichtenstein, 1818)	COGA
common goldeneye		Bucephala clangula�(Linnaeus, 1758)	COGO
common grackle		Quiscalus quiscula�(Linnaeus, 1758)	COGR
common greenshank		Tringa nebularia�(Gunnerus, 1767)		COMG
common ground dove		Columbina passerina�(Linnaeus, 1758)	CGDO
common loon		Gavia immer�(Brunnich, 1764)		COLO
common merganser		Mergus merganser�Linnaeus, 1758		COME
common murre		Uria aalge�(Pontoppidan, 1763)		COMU
common myna		Acridotheres tristis�(Linnaeus, 1766)	COMY
common nighthawk		Chordeiles minor�(J.R.Forster, 1771)	CONI
common pauraque		Nyctidromus albicollis�(Gmelin, 1789)	COPA
common pochard		Aythya ferina�(Linnaeus, 1758)		COMP
common poorwill		Phalaenoptilus nuttallii�(Audubon, 1844)	COPO
common raven		Corvus corax Linnaeus, 1758		CORA
common redpoll		Acanthis flammea�(Linnaeus, 1758)		CORE
common ringed plover		Charadrius hiaticula�Linnaeus, 1758		CRPL
common tern		Sterna hirundo�Linnaeus, 1758		COTE
common yellowthroat		Geothlypis trichas�(Linnaeus, 1766)		COYE
common scoter		Melanitta nigra�(Linnaeus, 1758)		COSC
common shelduck		Tadorna tadorna�(Linnaeus, 1758)		COMS
common swift		Apus apus�(Linnaeus, 1758)		COSW
connecticut warbler		Oporornis agilis�(A.Wilson, 1812)		CONW
cook's petrel		Pterodroma cookii�(G.R.Gray, 1843)	COPE
cooper's hawk		Accipiter cooperii�(Bonaparte, 1828)	COHA
cordilleran flycatcher		Empidonax occidentalis Nelson, 1897	COFL
cory's shearwater		Calonectris diomedea�(Scopoli, 1769)	CORS
costa's hummingbird		Calypte costae�(Bourcier, 1839)		COHU
couch's kingbird		Tyrannus couchii S.F.Baird, 1858		COKI
craveri's murrelet		Synthliboramphus craveri�(Salvadori, 1865)	CRMU
crescent-chested warbler	Oreothlypis superciliosa (Hartlaub, 1844)	CCWA
crested auklet		Aethia cristatella�(Pallas, 1769)		CRAU
crane hawk			Geranospiza caerulescens (Vieillot, 1817)	CRHA
crested bobwhite		Colinus cristatus�(Linnaeus, 1766)		CRBO
crested caracara		Caracara cheriway (Jacquin, 1784)		CRCA
crested myna		Acridotheres cristatellus�(Linnaeus, 1758)	CRMY
crimson-collared grosbeak	Rhodothraupis celaeno�(Deppe, 1830)	CCGR
crissal thrasher		Toxostoma crissale�Henry, 1858		CRTH
cuban pewee		Contopus caribaeus�(Orbigny, 1839)	CUPE
curlew sandpiper		Calidris ferruginea�(Pontoppidan, 1763)	CUSA
curve-billed thrasher		Toxostoma curvirostre�(Swainson, 1827)	CBTH
cuban vireo			Vireo gundlachii Lembeye, 1850		CUVI
dark-eyed junco		Junco hyemalis (Linnaeus, 1758)		DEJU
dickcissel			Spiza americana�(J.F.Gmelin, 1789)	DICK
double-crested cormorant	Phalacrocorax auritus�(Lesson, 1831)	DCCO
dovekie			Alle alle�(Linnaeus, 1758)		DOVE
double-toothed kite		Harpagus bidentatus�(Latham, 1790)	DTKI
downy woodpecker		Dryobates pubescens (Linnaeus, 1766)	DOWO
dunlin			Calidris alpi	na�(Linnaeus, 1758)		DUNL
dusky flycatcher		Empidonax oberholseri A.R.Phillips, 1939	DUFL
dusky grouse		Dendragapus obscurus�(Say, 1823)		DUGR
dusky warbler		Phylloscopus fuscatus (Blyth, 1842)	DUWA
eared grebe		Podiceps nigricollis�C.L.Brehm, 1831	EAGR
eared quetzal		Euptilotis neoxenus�(Gould, 1838)		EAQU
eastern bluebird		Sialia sialis (Linnaeus, 1758)		EABL
eastern kingbird		Tyrannus tyrannus�(Linnaeus, 1758)		EAKI
eastern meadowlark		Sturnella magna�(Linnaeus, 1758)		EAME
eastern phoebe		Sayornis phoebe (Latham, 1790)		EAPH
eastern screech-owl		Megascops asio (Linnaeus, 1758)		EASO
eastern towhee		Pipilo erythrophthalmus�(Linnaeus, 1758)	EATO
eastern spot-billed duck	Anas zonorhyncha�Swinhoe, 1866		ESBD
eastern whip-poor-will		Antrostomus vociferus�(A.Wilson, 1812)	EWPW
eastern wood-pewee		Contopus virens (Linnaeus, 1766)		EAWP
eastern yellow wagtail		Motacilla tschutschensis�Gmelin, 1789	EYWA
egyptian goose		Alopochen aegyptiaca�(Linnaeus, 1766)	EGGO
elf owl			Micrathene whitneyi (J.G.Cooper, 1861)	ELOW
emperor goose		Anser canagicus�(Sevastianov, 1802)	EMGO
eurasian collared-dove		Streptopelia decaocto�(Frivaldszky, 1838)	EUCD
eurasian dotterel		Charadrius morinellus�Linnaeus, 1758	EUDO
eurasian hobby		Falco subbuteo�Linnaeus, 1758		EHOB
erckel's francolin		Francolinus francolinus�(Linnaeus, 1766)	ERFR
eurasian kestrel		Falco tinnunculus�Linnaeus, 1758		EUKE
eurasian tree sparrow		Passer montanus (Linnaeus, 1758)		ETSP
eurasian skylark		Alauda arvensis�Linnaeus, 1758		EUSK
eurasian wigeon		Mareca penelope�(Linnaeus, 1758)		EUWI
eurasian jackdaw 		Coloeus monedula�(Linnaeus, 1758)	EUJA
european golden-plover	Pluvialis apricaria�(Linnaeus, 1758)		EUGP
european starling		Sturnus vulgaris Linnaeus, 1758		EUST
evening grosbeak		Coccothraustes vespertinus�(W.Cooper, 1825)	EVGR
eyebrowed thrush		Turdus obscurus�Gmelin, 1789		EYTH
falcated duck		Anas falcata�Georgi, 1775		FTSW
fan-tailed warbler		Basileuterus lachrymosus�(Bonaparte, 1850)	FTWA
ferruginous hawk		Buteo regalis (G.R.Gray, 1844)		FEHA
ferruginous pygmy-owl		Glaucidium brasilianum (Gmelin, 1788)	FEPO
field sparrow		Spizella pusilla�(A.Wilson, 1810)		FISP
fish crow			Corvus ossifragus Wilson, 1812		FICR
flame-colored tanager		Piranga bidentata Swainson, 1827		FCTA
flammulated owl		Psiloscops flammeolus (Kaup, 1852)	FLOW
flesh-footed shearwater		Puffinus carneipes�Gould, 1844		FFSH
florida scrub-jay		Aphelocoma coerulescens (Bosc, 1795)	FLSJ
fork-tailed swift		Apus pacificus�(Latham, 1802)		FTSW
fork-tailed storm-petrel		Hydrobates furcatus�(J.F.Gmelin, 1789)	FTSP
fork-tailed flycatcher		Tyrannus savana�Vieillot, 1808		FTFL
forster's tern		Sterna forsteri�Nuttall, 1834		FOTE
fox sparrow		Passerella iliaca (Merrem, 1786)		FOSP
franklin's gull		Leucophaeus atricilla�(Linnaeus, 1758)	FRGU
fulvous whistling-duck		Dendrocygna bicolor�(Vieillot, 1816)	FUWD
gadwall			Mareca strepera�(Linnaeus, 1758)		GADW
gambel's quail		Callipepla gambelii�(Gambel, 1843)		GAQU
garganey			Spatula querquedula�(Linnaeus, 1758)	GARG
gila woodpecker		Melanerpes uropygialis�(S.F.Baird, 1854)	GIWO
gilded flicker		Colaptes chrysoides (Malherbe, 1852)	GIFL
glaucous gull		Larus hyperboreus�Gunnerus, 1767		GLGU
glaucous-winged gull		Larus argentatus�Pontoppidan, 1763	GWGU
glossy ibis			Plegadis falcinellus (Linnaeus, 1766)	GLIB
golden eagle		Aquila chrysaetos (Linnaeus, 1758)		GOEA
golden-crowned kinglet		Regulus satrapa Lichtenstein, 1823		GCKI
golden-crowned sparrow	Zonotrichia atricapilla (J.F.Gmelin, 1789)	GCSP
golden-crowned warbler	Basileuterus culicivorus (Deppe, 1830)	GCRW
golden-fronted woodpecker	Melanerpes aurifrons (Wagler, 1829)	GFWO
golden-winged warbler		Vermivora chrysoptera�(Linnaeus, 1766)	GWWA
grace's warbler		Setophaga graciae�(S.F.Baird, 1865)	GRWA
grasshopper sparrow		Ammodramus savannarum (J.F.Gmelin, 1789)	GRSP
gray catbird		Dumetella carolinensis�(Linnaeus, 1766)	GRCA
gray flycatcher		Empidonax wrightii�S.F.Baird, 1858	GRFL
gray francolin		Francolinus pondicerianus�(Gmelin, 1789)	GRAF
gray hawk			Buteo nitidus�(Latham, 1790)		GRHA
gray heron			Ardea cinerea Linnaeus, 1758		GRAH
gray kingbird		Tyrannus dominicensis�(Gmelin, 1788)	GRAK
gray partridge		Tetraogallus himalayensis�G.R.Gray, 1843	GRAP
gray vireo			Vireo vicinior Coues, 1866		GRVI
gray-cheeked thrush		Catharus minimus�(Lafresnaye, 1848)	GCTH
gray-crowned rosy-finch	Leucosticte tephrocotis�(Swainson, 1832)	GCRF
gray-crowned yellowthroat	Geothlypis poliocephala�S.F.Baird, 1865	GCYE
gray-headed chickadee		Poecile cinctus (Boddaert, 1783)		GHCH
gray-headed swamphen	Porphyrio poliocephalus�(Latham, 1801)	GHSW
gray-tailed tattler		Tringa brevipes�(Vieillot, 1816)		GTTA
great black-backed gull		Larus marinus�Linnaeus, 1758		GBBG
graylag goose		Anser anser�(Linnaeus, 1758)		GRGO
great black hawk		Buteogallus urubitinga (Gmelin, 1788)	GBHA
great blue heron		Ardea herodias Linnaeus, 1758		GBHE
great cormorant		Phalacrocorax carbo�(Linnaeus, 1758)	GRCO
great crested flycatcher		Myiarchus crinitus (Linnaeus, 1758)	GCFL
great egret			Ardea alba Linnaeus, 1758		GREG
great gray owl		Strix nebulosa J.R.Forster, 1772		GGOW
great horned owl		Bubo virginianus (Gmelin, 1788)		GHOW
great kiskadee		Pitangus sulphuratus�(Linnaeus, 1766)	GKIS
great shearwater		Ardenna gravis�(O'Reilly, 1818)		GRSH
great skua			Stercorarius skua�(Brunnich, 1764)		GRSK
great-tailed grackle		Quiscalus mexicanus�(Gmelin, 1788)	GTGR
great spotted woodpecker	Dendrocopos major (Linnaeus, 1758)	GSWO
greater prairie-chicken		Tympanuchus cupido�(Linnaeus, 1758)	GRPC
greater sage-grouse		Centrocercus urophasianus�(Bonaparte, 1827)	GRSG
greater roadrunner		Geococcyx californianus�(Lesson, 1829)	GRRO
greater scaup		Aythya marila�(Linnaeus, 1761)		GRSC
greater white-fronted goose	Anser albifrons�(Scopoli, 1769)		GWFG
greater yellowlegs		Tringa melanoleuca�(Gmelin, 1789)		GRYE
green heron			Butorides virescens (Linnaeus, 1758)	GRHE
green jay			Cyanocorax yncas (Boddaert, 1783)	GRJA
green kingfisher		Chloroceryle americana (Gmelin, 1788)	GKIN
green-breasted mango		Anthracothorax prevostii�(Lesson, 1832)	GNBM
green-tailed towhee		Pipilo chlorurus�(Audubon, 1839)		GTTO
green-winged teal		Anas crecca�Linnaeus, 1758		GWTE
groove-billed ani		Crotophaga sulcirostris�Swainson, 1827	BGAN
gull-billed tern		Gelochelidon nilotica�(Gmelin, 1789)	GBTE
gunnison sage-grouse		Centrocercus urophasianus�(Bonaparte, 1827)	GUSG
gyrfalcon			Falco rusticolus�Linnaeus, 1758		GYRF
hairy woodpecker		Dryobates villosus (Linnaeus, 1766)	HAWO
harlequin duck		Somateria spectabilis�(Linnaeus, 1758)	HADU
harris's hawk		Parabuteo unicinctus�(Temminck, 1824)	HASH
harris's sparrow		Zonotrichia querula�(Nuttall, 1840)		HASP
hawaiian crow		Corvus hawaiiensis Peale, 1848		HCRO
hawaiian duck		Anas wyvilliana�Sclater, 1878		HAWD
hawaiian goose		Branta sandvicensis�(Vigors, 1834)		HAGO
hawaiian hawk		Buteo solitarius Peale, 1848		HAWH
heermann's gull		Larus heermanni�Cassin, 1852		HEEG
henslow's sparrow		Ammodramus henslowii�(Audubon, 1829)	HESP
hepatic tanager		Piranga flava (Vieillot, 1822)		HETA
hermit thrush		Catharus guttatus (Pallas, 1811)		HETH
hermit warbler		Setophaga occidentalis (J.K.Townsend, 1837)	HEWA
herring gull			Larus argentatus�Pontoppidan, 1763	HERG
himalayan snowcock		Pternistis erckelii�(Ruppell, 1835)		HISN
hoary redpoll		Acanthis hornemanni�(Holb�ll, 1843)	HORE
hooded merganser		Lophodytes cucullatus�(Linnaeus, 1758)	HOME
hooded oriole		Icterus cucullatus�Swainson, 1827		HOOR
hooded warbler		Setophaga citrina�(Boddaert, 1783)		HOWA
hook-billed kite		Chondrohierax uncinatus�(Temminck, 1822)	HBKI
horned grebe		Podiceps auritus�(Linnaeus, 1758)		HOGR
horned lark			Eremophila alpestris (Linnaeus, 1758)	HOLA
horned puffin		Fratercula corniculata�(J.F.Naumann, 1821)	HOPU
house sparrow		Passer domesticus (Linnaeus, 1758)	HOSP
house wren			Troglodytes aedon Vieillot, 1809		HOWR
hudsonian godwit		Limosa haemastica�(Linnaeus, 1758)	HUGO
hutton's vireo		Vireo huttoni Cassin, 1851		HUVI
iceland gull			Larus glaucoides�B.Meyer, 1822		ICGU
inca dove			Columbina inca�(Lesson, 1847)		INDO
indigo bunting		Passerina cyanea�(Linnaeus, 1766)		INBU
indian peafowl		Pavo cristatus�Linnaeus, 1758		INPE
intermediate egret		Ardea intermedia Wagler, 1827		INEG
island scrub-jay		Aphelocoma insularis Henshaw, 1886	ISSJ
ivory-billed woodpecker	Campephilus principalis (Linnaeus, 1758)	IBWO
ivory gull			Pagophila eburnea�(Phipps, 1774)		IVGU
jabiru			Jabiru mycteria�(Lichtenstein, 1819)	JABI
juniper titmouse		Baeolophus ridgwayi�(Richmond, 1902)	JUTI
kelp gull			Larus dominicanus�Lichtenstein, 1823	KEGU
kentucky warbler		Geothlypis formosa (A.Wilson, 1811)	KEWA
key west quail-dove		Geotrygon chrysia�Bonaparte, 1855	KWQD
killdeer			Charadrius vociferus�Linnaeus, 1758	KILL
kalij pheasant		Lophura leucomelanos�(Latham, 1790)	KAPH
king eider			Somateria spectabilis�(Linnaeus, 1758)	KIEI
king rail			Rallus elegans�Audubon, 1834		KIRA
kirtland's warbler		Setophaga kirtlandii�(S.F.Baird, 1852)	KIWA
kittlitz's murrelet		Brachyramphus brevirostris�(Vigors, 1829)	KIMU
la sagra's flycatcher		Myiarchus sagrae�(Gundlach, 1852)	LSFL
lanceolated warbler		Locustella lanceolata�(Temminck, 1840)	LANW
lapland longspur		Calcarius lapponicus�(Linnaeus, 1758)	LALO
labrador duck		Histrionicus histrionicus�(Linnaeus, 1758)	LABD
lark bunting			Calamospiza melanocorys Stejneger, 1885	LARB
lark sparrow		Chondestes grammacus (Say, 1822)	LASP
laughing gull		Leucophaeus atricilla�(Linnaeus, 1758)	LAGU
lawrence's goldfinch		Spinus lawrencei�(Cassin, 1850)		LAGO
laysan albatross		Spinus lawrencei�(Cassin, 1850)		LAAL
lazuli bunting		Passerina amoena�(Say, 1822)		LAZB
laysan duck			Anas laysanensis�Rothschild, 1892		LAYD
leach's storm-petrel		Hydrobates leucorhous�(Vieillot, 1818)	LESP
least auklet			Aethia pusilla�(Pallas, 1811)		LEAU
least bittern			Ixobrychus exilis (Gmelin, 1789)		LEBI
least grebe			Tachybaptus dominicus�(Linnaeus, 1766)	LEGR
least sandpiper		Calidris minutilla�(Vieillot, 1819)		LESA
least storm-petrel		Oceanodroma microsoma�(Coues, 1864)	LSTP
least tern			Sternula antillarum�Lesson, 1847		LETE
leconte's sparrow		Ammospiza leconteii�(Audubon, 1844)	LCSP
leconte's thrasher		Toxostoma lecontei�Lawrence, 1851	LCTH
lesser black-backed gull	Larus fuscus�Linnaeus, 1758		LBBG
lesser goldfinch		Spinus psaltria�(Say, 1822)		LEGO
lesser nighthawk		Chordeiles acutipennis�(Hermann, 1783)	LENI
lesser prairie-chicken		Tympanuchus pallidicinctus�(Ridgway, 1873)	LEPC
lesser sand-plover		Spinus psaltria�(Say, 1822)		LSAP
lesser scaup		Aythya affinis�(Eyton, 1838)		LESC
lesser yellowlegs		Tringa flavipes�(Gmelin, 1789)		LEYE
lesser white-fronted goose	Anser erythropus�(Linnaeus, 1758)		LWFG
lewis's woodpecker		Melanerpes lewis (G.R.Gray, 1849)	LEWO
limpkin			Aramus guarauna�(Linnaeus, 1766)		LIMP
lincoln's sparrow		Melospiza lincolnii (Audubon, 1834)	LISP
little blue heron		Egretta caerulea (Linnaeus, 1758)		LBHE
little bunting			Emberiza pusilla�Pallas, 1776		LIBU
little curlew			Numenius minutus�Gould, 1841		LICU
little egret			Egretta garzetta (Linnaeus, 1766)		LIEG
little gull			Hydrocoloeus minutus�(Pallas, 1776)	LIGU
little stint			Calidris minuta�(Leisler, 1812)		LIST
loggerhead kingbird		Tyrannus caudifasciatus�Orbigny, 1839	LOKI
loggerhead shrike		Lanius ludovicianus Linnaeus, 1766		LOSH
long-billed curlew		Numenius americanus�Bechstein, 1812	LBCU
long-billed dowitcher		Limnodromus scolopaceus�(Say, 1822)	LBDO
long-billed murrelet		Brachyramphus perdix�(Pallas, 1811)	LBMU
long-billed thrasher		Toxostoma longirostre�(Lafresnaye, 1838)	LBTH
long-eared owl		Asio otus (Linnaeus, 1758)		LEOW
long-tailed duck		Clangula hyemalis�(Linnaeus, 1758)		LTDU
long-tailed jaeger		Stercorarius longicaudus�Vieillot, 1819	LTJA
louisiana waterthrush		Parkesia motacilla�(Vieillot, 1809)		LOWA
lucifer hummingbird		Calothorax lucifer�(Swainson, 1827)	LUHU
lucy's warbler		Leiothlypis luciae (J.G.Cooper, 1861)	LUWA
macgillvray's warbler		Geothlypis tolmiei (J.K.Townsend, 1839)	MGWA
magnificent frigatebird		Fregata magnificens�Mathews, 1914	MAFR
magnolia warbler		Setophaga magnolia�(A.Wilson, 1811)	MAWA
mallard			Anas platyrhynchos�Linnaeus, 1758		MALL
mangrove cuckoo		Coccyzus minor�(Gmelin, 1788)		MACU
manx shearwater		Coccyzus minor (Gmelin, 1788)		MASH
marbled godwit		Limosa fedoa�(Linnaeus, 1758)		MAGO
marbled murrelet		Brachyramphus marmoratus�(Gmelin, 1789)	MAMU
marsh wren			Cistothorus palustris (A.Wilson, 1810)	MAWR
masked booby		Sula dactylatra�Lesson, 1831		MABO
masked duck		Nomonyx dominicus�(Linnaeus, 1766)	MADU
mccown's longspur		Rhynchophanes mccownii�(Lawrence, 1851)	MCLO
mckay's bunting		Plectrophenax nivalis�(Linnaeus, 1758)	KMBU
merlin			Falco columbarius Linnaeus, 1758		MERL
mew gull			Larus canus�Linnaeus, 1758		MEGU
mexican chickadee		Poecile sclateri (O.Kleinschmidt, 1897)	MECH
mexican jay			Aphelocoma wollweberi Kaup, 1855	MEJA
mexican violetear		Colibri thalassinus (Swainson, 1827)	MEVI
mexican whip-poor-will		Antrostomus arizonae�Brewster, 1881	MWPW
mississippi kite		Ictinia mississippiensis�(A.Wilson, 1811)	MIKI
montezuma quail		Cyrtonyx montezumae�(Vigors, 1830)	MONQ
mottled duck		Anas fulvigula�Ridgway, 1874		MODU
mottled petrel		Pterodroma inexpectata�(J.R.Forster, 1844)	MOPE
mottled owl			Ciccaba virgata (Cassin, 1849)		MOOW
mountain bluebird		Sialia currucoides (Bechstein, 1798)	MOBL
mountain chickadee		Poecile gambeli (Ridgway, 1886)		MOCH
mountain plover		Charadrius montanus�J.K.Townsend, 1837	MOPL
mountain quail		Oreortyx picta�(Douglas, 1829)		MOUQ
mourning dove		Zenaida macroura�(Linnaeus, 1758)	MODO
mourning warbler		Geothlypis philadelphia�(A.Wilson, 1810)	MOWA
murphy's petrel		Pterodroma ultima�Murphy, 1949		MUPE
muscovy duck		Cairina moschata�(Linnaeus, 1758)		MUDU
mute swan			Cygnus olor�(Gmelin, 1789)		MUSW
nashville warbler		Leiothlypis ruficapilla (A.Wilson, 1811)	NAWA
nelson's sparrow		Ammodramus nelsoni�J.A.Allen, 1875	NESP
neotropic cormorant		Phalacrocorax brasilianus�(Gmelin, 1789)	NECO
northern beardless-tyrannulet	Camptostoma imberbe�P.L.Sclater, 1857	NOBT
northern bobwhite		Colinus virginianus�(Linnaeus, 1758)	NOBO
northern cardinal		Cardinalis cardinalis�(Linnaeus, 1758)	NOCA
northern boobook		Ninox scutulata (Raffles, 1822)		NOBB
northern flicker		Colaptes auratus (Linnaeus, 1758)		NOFL
northern fulmar		Fulmarus glacialis�(Linnaeus, 1761)		NOFU
northern gannet		Morus bassanus (Linnaeus, 1758)		NOGA
northern goshawk		Accipiter gentilis�(Linnaeus, 1758)		NOGO
northern harrier		Circus hudsonius (Linnaeus, 1766)		NOHA
northern hawk owl		Surnia ulula (Linnaeus, 1758)		NHOW
northern jacana		Jacana spinosa�(Linnaeus, 1758)		NOJA
northern lapwing		Vanellus vanellus (Linnaeus, 1758)		NOLA
northern mockingbird		Mimus polyglottos (Linnaeus, 1758)	NOMO
northern parula		Setophaga americana (Linnaeus, 1758)	NOPA
northern pintail		Anas acuta Linnaeus, 1758		NOPI
northern pygmy-owl		Glaucidium gnoma Wagler, 1832		NOPO
northern red bishop		Euplectes franciscanus�(Isert, 1789)	NRBI
northern rough-winged swallow	Stelgidopteryx serripennis (Audubon, 1838)	NRWS
northern saw-whet owl		Aegolius acadicus (Gmelin, 1788)		NSWO
northern shoveler		Spatula clypeata�(Linnaeus, 1758)		NSHO
northern shrike		Lanius borealis Viellot, 1808		NSHR
northern waterthrush		Parkesia noveboracensis (J.F.Gmelin, 1789)	NOWA
northern wheatear		Oenanthe oenanthe (Linnaeus, 1758)	NOWH
northwestern crow		Corvus caurinus S.F.Baird, 1858		NOCR
nutting's flycatcher		Myiarchus nuttingi Ridgway, 1882		NUFL
oak titmouse		Baeolophus inornatus (Gambel, 1845)	OATI
olive sparrow		Arremonops rufivirgatus (Lawrence, 1851)	OLSP
olive-backed pipit		Anthus trivialis�(Linnaeus, 1758)		OBPI
olive-sided flycatcher		Contopus cooperi (Nuttall, 1831)		OSFL
orange-crowned warbler	Leiothlypis celata�(Say, 1822)		OCWA
orchard oriole		Icterus spurius�(Linnaeus, 1766)		OROR
oriental turtle-dove		Streptopelia orientalis�(Latham, 1790)	ORTD
oriental scops-owl		Otus sunia�(Hodgson, 1836)		ORSO
osprey			Pandion haliaetus (Linnaeus, 1758)		OSPR
ovenbird			Seiurus aurocapilla�(Linnaeus, 1766)	OVEN
pacific golden-plover		Pluvialis fulva�(Gmelin, 1789)		PAGP
pacific black duck		Anas superciliosa�Gmelin, 1789		PABD
pacific loon			Gavia pacifica�(Lawrence, 1858)		PALO
pacific wren		Troglodytes pacificus S.F.Baird, 1864	PAWR
pacific-slope flycatcher		Empidonax difficilis S.F.Baird, 1858	PSFL
painted bunting		Passerina ciris (Linnaeus, 1758)		PABU
painted redstart		Myioborus pictus�(Swainson, 1829)	PARE
palm warbler		Setophaga palmarum�(J.F.Gmelin, 1789)	PAWA
parakeet auklet		Aethia psittacula�(Pallas, 1769)		PAAU
parasitic jaeger		Stercorarius parasiticus�(Linnaeus, 1758)	PAJA
pechora pipit		Anthus gustavi�Swinhoe, 1863		PEPI
pectoral sandpiper		Calidris melanotos�(Vieillot, 1819)		PESA
pelagic cormorant		Phalacrocorax pelagicus Pallas, 1811	PECO
peregrine falcon		Falco peregrinus Tunstall, 1771		PEFA
phainopepla		Phainopepla nitens�(Swainson, 1838)	PHAI
philadelphia vireo		Vireo philadelphicus�(Cassin, 1851)		PHVI
pied-billed grebe		Podilymbus podiceps�(Linnaeus, 1758)	PBGR
pigeon guillemot		Cepphus columba Pallas, 1811		PIGU
pileated woodpecker		Dryocopus pileatus (Linnaeus, 1758)	PIWO
pine grosbeak		Pinicola enucleator�(Linnaeus, 1758)	PIGR
pine flycatcher		Empidonax affinis (Swainson, 1827)	PINF
pine siskin			Spinus pinus�(A.Wilson, 1810)		PISI
pine warbler		Setophaga pinus (Linnaeus, 1766)		PIWA
pink-footed goose		Anser brachyrhynchus�Baillon, 1834	PFGO
pink-footed shearwater		Ardenna creatopus (Coues, 1864)		PFSH
pinyon jay			Gymnorhinus cyanocephalus Wied-Neuwied, 1841	PIJA
piping plover		Charadrius melodus Ord, 1824		PIPL
piratic flycatcher		Legatus leucophaius (Vieillot, 1818)	PIRF
plain chachalaca		Ortalis vetula (Wagler, 1830)		PLCH
plain-capped starthroat		Heliomaster constantii�(Delattre, 1843)	PCST
plumbeous vireo		Vireo plumbeus Coues, 1866		PLVI
pomarine jaeger		Stercorarius pomarinus (Temminck, 1815)	POJA
prairie falcon		Falco mexicanus Schlegel, 1850		PRFA
prairie warbler		Setophaga discolor (Vieillot, 1809)		PRAW
prothonotary warbler		Protonotaria citrea (Boddaert, 1783)	PROW
purple finch			Haemorhous purpureus (J.F.Gmelin, 1789)	PUFI
purple gallinule		Porphyrio martinica (Linnaeus, 1766)	PUGA
purple martin		Progne subis (Linnaeus, 1758)		PUMA
purple sandpiper		Calidris maritima (Brunnich, 1764)		PUSA
pygmy nuthatch		Sitta pygmaea Vigors, 1839		PYNU
pyrrhuloxia			Cardinalis sinuatus Bonaparte, 1838	PYRR
razorbill			Alca torda Linnaeus, 1758		RAZO
red crossbill		Loxia curvirostra Linnaeus, 1758		RECR
red knot			Calidris canutus (Linnaeus, 1758)		REKN
red phalarope		Phalaropus fulicarius (Linnaeus, 1758)	REPH
red junglefowl		Gallus gallus�(Linnaeus, 1758)		REJU
red-bellied woodpecker	Melanerpes carolinus (Linnaeus, 1758)	RBWO
red-billed pigeon		Patagioenas flavirostris (Wagler, 1831)	RBPI
red-billed tropicbird		Phaethon aethereus Linnaeus, 1758		RBTR
red-breasted merganser	Mergus serrator�Linnaeus, 1758		RBME
red-breasted nuthatch		Sitta canadensis Linnaeus, 1766		RBNU
red-breasted sapsucker		Sphyrapicus ruber (Gmelin, 1788)		RBSA
red-cockaded woodpecker	Picoides borealis (Vieillot, 1809)		RCWO
reddish egret		Egretta rufescens (Gmelin, 1789)		REEG
red-eyed vireo		Vireo olivaceus (Linnaeus, 1766)		REVI
red-faced cormorant		Phalacrocorax urile�(Gmelin, 1789)		RFCO
red-footed booby		Sula sula (Linnaeus, 1766)		RFBO
red-footed falcon		Falco vespertinus�Linnaeus, 1766		RFFA
redhead			Aythya americana�(Eyton, 1838)		REDH
red-headed woodpecker	Melanerpes erythrocephalus (Linnaeus, 1758)	RHWO
red-legged kittiwake		Rissa brevirostris (Bruch, 1853)		RLKI
red-naped sapsucker		Sphyrapicus nuchalis�S.F.Baird, 1858	RNSA
red-necked grebe		Podiceps grisegena�(Boddaert, 1783)	RNGR
red-necked phalarope		Phalaropus lobatus (Linnaeus, 1758)	RNPH
red-necked stint		Calidris ruficollis (Pallas, 1776)		RNST
red-shouldered hawk		Buteo lineatus�(Gmelin, 1788)		RSHA
red-tailed hawk		Buteo jamaicensis�(Gmelin, 1788)		RTHA
red-tailed tropicbird		Phaethon rubricauda Boddaert, 1783	RTTR
red-throated loon		Gavia stellata�(Pontoppidan, 1763)		RTLO
red-throated pipit		Anthus cervinus (Pallas, 1811)		RTPI
red-whiskered bulbul		Pycnonotus cafer (Linnaeus, 1766)		RVBU
red-winged blackbird		Agelaius phoeniceus�(Linnaeus, 1766)	RWBL
redwing			Turdus iliacus Linnaeus, 1766		REDW
rhinoceros auklet		Cerorhinca monocerata (Pallas, 1811)	RHAU
ring-billed gull		Larus delawarensis Ord, 1815		RBGU
ringed kingfisher		Megaceryle torquata (Linnaeus, 1766)	RIKI
ring-necked duck		Aythya collaris�(Donovan, 1809)		RNDU
rivoli's hummingbird		Eugenes fulgens (Swainson, 1827)		RIHU
ring-necked pheasant		Phasianus colchicus�Linnaeus, 1758		RNEP
roadside hawk		Rupornis magnirostris�(Gmelin, 1788)	ROHA
rock pigeon		Columba livia Gmelin, 1789		ROPI
rock ptarmigan		Lagopus muta�(Montin, 1781)		ROPT
rock sandpiper		Calidris ptilocnemis�(Coues, 1873)		ROSA
rock wren			Salpinctes obsoletus�(Say, 1822)		ROWR
rose-breasted grosbeak	Pheucticus ludovicianus�(Linnaeus, 1766)	RBGR
rose-throated becard		Pachyramphus aglaiae (Lafresnaye, 1839)	RTBE
roseate spoonbill		Ajaia ajaja (Linnaeus, 1758)		ROSP
roseate tern			Sterna dougallii�Montagu, 1813		ROST
ross's goose		Anser rossii�Cassin, 1861		ROGO
ross's gull			Rhodostethia rosea (MacGillivray, 1824)	ROGU
rough-legged hawk		Buteo lagopus (Pontoppidan, 1763)	RLHA
royal tern			Thalasseus maximus (Boddaert, 1783)	ROYT
ruby-crowned kinglet		Regulus calendula (Linnaeus, 1766)		RCKI
ruby-throated hummingbird	Archilochus colubris�(Linnaeus, 1758)	RTHU
ruddy duck			Oxyura jamaicensis�(Gmelin, 1789)		RUDU
ruddy ground dove		Columbina talpacoti (Temminck, 1810)	RGDO
ruddy quail-dove		Geotrygon montana�(Linnaeus, 1758)	RUQD
ruddy turnstone		Arenaria interpres (Linnaeus, 1758)		RUTU
ruff			Calidris pugnax (Linnaeus, 1758)		RUFF
ruffed grouse		Bonasa umbellus�(Linnaeus, 1766)		RUGR
rufous hummingbird		Selasphorus rufus�(Gmelin, 1788)		RUHU
rufous-backed robin		Turdus rufopalliatus Lafresnaye, 1840	RBRO
rufous-capped warbler		Basileuterus rufifrons (Swainson, 1838)	RCWA
rufous-crowned sparrow	Aimophila ruficeps (Cassin, 1852)		RCSP
rufous-winged sparrow		Peucaea carpalis Coues, 1873		RWSP
rustic bunting		Emberiza rustica�Pallas, 1776		RUBU
sabine's gull			Xema sabini (Sabine, 1819)		SAGU
sage thrasher		Oreoscoptes montanus�(J.K.Townsend, 1837)	SATH
sagebrush sparrow		Artemisiospiza nevadensis (Ridgway, 1874)	SABS
saltmarsh sparrow		Ammospiza caudacutus (J.F.Gmelin, 1788)	SALS
sanderling			Calidris alba (Pallas, 1764)		SAND
sandhill crane		Antigone canadensis�(Linnaeus, 1758)	SACR
sandwich tern		Thalasseus sandvicensis�(Latham, 1787)	SATE
savannah sparrow		Passerculus sandwichensis�(J.F.Gmelin, 1789)	SAVS
say's phoebe		Sayornis saya (Bonaparte, 1825)		SAPH
scaled quail			Callipepla squamata�(Vigors, 1830)		SCQU
scaly-breasted munia		Lonchura punctulata (Linnaeus, 1758)	SBMU
scarlet ibis			Eudocimus ruber (Linnaeus, 1758)		SCIB
scarlet tanager		Piranga olivacea (J.F.Gmelin, 1789)	SCTA
scissor-tailed flycatcher		Tyrannus forficatus�(Gmelin, 1789)		STFL
scott's oriole		Icterus parisorum Bonaparte, 1838		SCOR
seaside sparrow		Ammospiza maritima (A.Wilson, 1811)	SESP
sedge wren			Cistothorus platensis (Latham, 1790)	SEWR
semipalmated plover		Charadrius semipalmatus Bonaparte, 1825	SEPL
semipalmated sandpiper	Calidris pusilla (Linnaeus, 1766)		SESA
sharp-shinned hawk		Accipiter striatus Vieillot, 1808		SSHA
sharp-tailed grouse		Tympanuchus phasianellus�(Linnaeus, 1758)	STGR
sharp-tailed sandpiper		Calidris acuminata (Horsfield, 1821)	SPTS
shiny cowbird		Molothrus bonariensis (Gmelin, 1789)	SHCO
short-billed dowitcher		Limnodromus griseus (Gmelin, 1789)	SBDO
short-eared owl		Asio flammeus (Pontoppidan, 1763)	SEOW
short-tailed albatross		Phoebastria albatrus�(Pallas, 1769)		STAL
short-tailed hawk		Buteo brachyurus�Vieillot, 1816		STHA
short-tailed shearwater		Ardenna tenuirostris (Temminck, 1835)	STTS
siberian accentor		Prunella montanella�(Pallas, 1776)		SIAC
siberian rubythroat		Calliope calliope (Pallas, 1776)		SIRU
sinaloa wren		Thryothorus sinaloa (S.F.Baird, 1864)	SIWR
slate-throated redstart		Myioborus miniatus (Swainson, 1827)	STRE
slaty-backed gull		Larus schistisagus�Stejneger, 1884		SBGU
smew			Mergellus albellus�(Linnaeus, 1758)		SMEW
smith's longspur		Calcarius pictus (Swainson, 1832)		SMLO
smooth-billed ani		Crotophaga ani Linnaeus, 1758		SBAN
snail kite			Rostrhamus sociabilis�(Vieillot, 1817)	SNKI
snow bunting		Plectrophenax nivalis (Linnaeus, 1758)	SNBU
snow goose		Anser caerulescens�(Linnaeus, 1758)	SNGO
snowy egret		Egretta thula (Molina, 1782)		SNEG
snowy owl			Bubo scandiacus (Linnaeus, 1758)		SNOW
snowy plover		Charadrius nivosus (Cassin, 1858)		SNPL
solitary sandpiper		Tringa solitaria Wilson, 1813		SOSA
song sparrow		Melospiza melodia (A.Wilson, 1810)	SOSP
sooty shearwater		Ardenna grisea (Gmelin, 1789)		SOSH
sooty tern			Onychoprion fuscatus (Linnaeus, 1766)	SOTE
sora			Porzana carolina (Linnaeus, 1758)		SORA
south polar skua		Stercorarius maccormicki H.Saunders, 1893	SPSK
spectacled eider		Somateria fischeri (Brandt, 1847)		SPEI
spot-breasted oriole		Icterus pectoralis�(Wagler, 1829)		SBOR
spotted dove		Streptopelia chinensis (Scopoli, 1786)	SPDO
spotted redshank		Tringa erythropus (Pallas, 1764)		SPRE
spotted sandpiper		Actitis macularius (Linnaeus, 1766)		SPSA
spotted towhee		Pipilo maculatus Swainson, 1827		SPTO
sprague's pipit		Anthus spragueii (Audubon, 1844)		SPPI
spruce grouse		Falcipennis canadensis�(Linnaeus, 1758)	SPGR
stejneger's scoter		Melanitta stejnegeri�(Ridgway, 1887)	STSC
steller's eider		Polysticta stelleri�(Pallas, 1769)		STEI
steller's jay			Cyanocitta stelleri (Gmelin, 1788)		STJA
stilt sandpiper		Calidris himantopus (Bonaparte, 1826)	STSA
streak-backed oriole		Icterus pustulatus (Wagler, 1829)		SBAO
steller's sea-eagle		Haliaeetus pelagicus (Pallas, 1811)		STSE
stygian owl			Asio stygius (Wagler, 1832)		STOW
sulphur-bellied flycatcher	Myiodynastes luteiventris P.L.Sclater, 1859	SBFL
summer tanager		Piranga rubra (Linnaeus, 1758)		SUTA
surf scoter			Melanitta perspicillata�(Linnaeus, 1758)	SUSC
swainson's hawk		Buteo swainsoni�Bonaparte, 1838		SWHA
swainson's thrush		Catharus ustulatus (Nuttall, 1840)		SWTH
swainson's warbler		Limnothlypis swainsonii (Audubon, 1834)	SWWA
swallow-tailed kite		Elanoides forficatus (Linnaeus, 1758)	STKI
swamp sparrow		Melospiza georgiana (Latham, 1790)	SWSP
taiga bean-goose		Anser fabalis�(Latham, 1787)		TABG
tamaulipas crow		Corvus imparatus J.L.Peters, 1929		TACR
temminck's stint		Calidris temminckii (Leisler, 1812)		TEST
tennessee warbler		Leiothlypis peregrina�(A.Wilson, 1811)	TEWA
terek sandpiper		Xenus cinereus�(Guldenstadt, 1775)	TESA
thick-billed vireo		Vireo crassirostris�(H.Bryant, 1859)	TBVI
thick-billed kingbird		Tyrannus crassirostris Swainson, 1826	TBKI
thick-billed murre		Uria lomvia (Linnaeus, 1758)		TBMU
townsend's solitaire		Myadestes townsendi (Audubon, 1838)	TOSO
townsend's warbler		Setophaga townsendi (J.K.Townsend, 1837)	TOWA
tree swallow		Tachycineta bicolor (Vieillot, 1808)		TRES
tricolored blackbird		Agelaius tricolor�(Audubon, 1837)		TRBL
tropical kingbird		Tyrannus melancholicus Vieillot, 1819	TRKI
tropical parula		Setophaga pitiayumi (Vieillot, 1817)	TRPA
trumpeter swan		Cygnus buccinator�Richardson, 1831	TRUS
tufted duck			Aythya fuligula�(Linnaeus, 1758)		TUDU
tufted flycatcher		Mitrephanes phaeocercus (P.L.Sclater, 1859)	TUFL
tufted puffin 		Fratercula cirrhata (Pallas, 1769)		TUPU
tufted titmouse		Baeolophus bicolor (Linnaeus, 1766)	TUTI
tundra bean-goose		Anser serrirostris�Swinhoe, 1871		TUBG
tundra swan		Cygnus columbianus�(Ord, 1815)		TUSW
turkey vulture		Cathartes aura (Linnaeus, 1758)		TUVU
upland sandpiper		Bartramia longicauda (Bechstein, 1812)	UPSA
varied bunting		Passerina versicolor (Bonaparte, 1838)	VABU
varied thrush		Ixoreus naevius (Gmelin, 1789)		VATH
variegated flycatcher		Empidonomus varius�(Vieillot, 1818)	VAFL
vaux's swift			Chaetura vauxi�(J.K.Townsend, 1839)	VASW
veery			Catharus fuscescens (Stephens, 1817)	VEER
verdin			Auriparus flaviceps (Sundevall, 1850)	VERD
velvet scoter		Melanitta fusca�(Linnaeus, 1758)		VESC
vermilion flycatcher		Pyrocephalus rubinus (Boddaert, 1783)	VEFL
vesper sparrow		Pooecetes gramineus (J.F.Gmelin, 1789)	VESP
violet-crowned hummingbird	Amazilia violiceps�(Gould, 1859)		VCHU
violet-green swallow		Tachycineta thalassina (Swainson, 1827)	VGSW
virginia rail			Rallus limicola Vieillot, 1819		VIRA
virginia's warbler		Leiothlypis virginiae (S.F.Baird, 1860)	VIWA
warbling vireo		Vireo gilvus�(Vieillot, 1808)		WAVI
wedge-rumped storm-petrel	Oceanodroma tethys�(Bonaparte, 1852)	WRSP
wedge-tailed shearwater	Ardenna pacifica (Gmelin, 1789)		WTSH
western bluebird		Sialia mexicana Swainson, 1832		WEBL
western grebe		Aechmophorus occidentalis�(Lawrence, 1858)	WEGR
western gull			Larus occidentalis Audubon, 1839		WEGU
western kingbird		Tyrannus verticalis Say, 1823		WEKI
western meadowlark		Sturnella neglecta Audubon, 1844		WEME
western reef-heron		Egretta gularis (Bosc, 1792)		WERH
western sandpiper		Calidris mauri (Cabanis, 1857)		WESA
western screech-owl		Megascops kennicottii (Elliot, 1867)	WESO
western spindalis		Spindalis zena (Linnaeus, 1758)		WESP
western tanager		Piranga ludoviciana (A.Wilson, 1811)	WETA
western wood-pewee		Contopus sordidulus P.L.Sclater, 1859	WEWP
whimbrel			Numenius phaeopus (Linnaeus, 1758)	WHIM
whiskered auklet		Aethia pygmaea (Gmelin, 1789)		WHAU
west-indian whistling-duck	Dendrocygna arborea�(Linnaeus, 1758)	WIWD
whiskered screech-owl		Megascops trichopsis�(Wagler, 1832)	WHSO
white ibis			Eudocimus albus (Linnaeus, 1758)		WHIB
white wagtail		Motacilla alba Linnaeus, 1758		WHWA
white-breasted nuthatch	Sitta carolinensis Latham, 1790		WBNU
white-cheeked pintail		Anas bahamensis�Linnaeus, 1758		WCHP
white-collared swift		Streptoprocne zonaris�(Shaw, 1796	)	WCSW
white-crowned sparrow	Zonotrichia leucophrys (J.R.Forster, 1772)	WCSP
white-eared hummingbird	Hylocharis leucotis�(Vieillot, 1818)		WEHU
white-eyed vireo		Vireo griseus (Boddaert, 1783)		WEVI
white-faced ibis		Plegadis chihi (Vieillot, 1817)		WFIB
white-faced storm-petrel	Pelagodroma marina (Latham, 1790)	WFSP
white-faced whistling-duck	Dendrocygna viduata�(Linnaeus, 1766)	WFWD
white-headed woodpecker	Picoides albolarvatus (Cassin, 1850)	WHWO
white-rumped sandpiper	Calidris fuscicollis (Vieillot, 1819)		WRSA
white-tailed eagle		Haliaeetus albicilla (Linnaeus, 1758)	WTEA
white-tailed hawk		Geranoaetus albicaudatus (Vieillot, 1816)	WTHA
white-tailed kite		Elanus leucurus (Vieillot, 1818)		WTKI
white-tailed ptarmigan		Lagopus leucura�(Richardson, 1831)	WTPT
white-tailed tropicbird		Phaethon lepturus Daudin, 1802		WTTR
white-throated needletail	Hirundapus caudacutus�(Latham, 1802)	WTNE
white-throated sparrow		Zonotrichia albicollis (J.F.Gmelin, 1789)	WTSP
white-throated swift		Aeronautes saxatalis�(Woodhouse, 1853)	WTSW
white-throated thrush		Turdus assimilis Cabanis, 1850		WTTH
white-tipped dove		Leptotila verreauxi (Bonaparte, 1855)	WTDO
white-winged crossbill		Loxia leucoptera J.F.Gmelin, 1789		WWCR
white-winged dove		Zenaida asiatica (Linnaeus, 1758)		WWDO
white-winged scoter		Melanitta deglandi�(Bonaparte, 1850)	WWSC
white-winged tern		Chlidonias leucopterus (Temminck, 1815)	WWTE
whooper swan		Cygnus cygnus�(Linnaeus, 1758)		WHOS
whooping crane		Grus americana�(Linnaeus, 1758)		WHCR
wild turkey			Meleagris gallopavo�Linnaeus, 1758	WITU
willet			Tringa semipalmata (Gmelin, 1789)		WILL
williamson's sapsucker		Sphyrapicus thyroideus (Cassin, 1852)	WISA
willow flycatcher		Empidonax traillii (Audubon, 1828)		WIFL
willow ptarmigan		Lagopus lagopus�(Linnaeus, 1758)		WIPT
willow warbler		Phylloscopus trochilus (Linnaeus, 1758)	WILW
wilson's phalarope		Phalaropus tricolor (Vieillot, 1819)		WIPH
wilson's plover		Charadrius wilsonia Ord, 1814		WIPL
wilson's snipe		Gallinago delicata (Ord, 1825)		WISN
wilson's storm-petrel		Oceanites oceanicus (Kuhl, 1820)		WISP
wilson's warbler		Cardellina pusilla (A.Wilson, 1811)		WIWA
winter wren			Troglodytes hiemalis�Vieillot, 1819		WIWR
wood duck			Aix sponsa�(Linnaeus, 1758)		WODU
wood sandpiper		Tringa glareola Linnaeus, 1758		WOSA
wood stork			Mycteria americana Linnaeus, 1758	WOST
wood thrush		Hylocichla mustelina (Gmelin, 1789)	WOTH
wood warbler		Phylloscopus sibillatrix (Bechstein, 1792)	WOWA
woodhouse's scrub-jay		Aphelocoma woodhouseii (S.F.Baird, 1858)	WOSJ
worm-eating warbler		Helmitheros vermivorum (J.F.Gmelin, 1789)	WEWA
wrentit			Chamaea fasciata (Gambel, 1845)		WREN
xantus's hummingbird		Hylocharis xantusii�(Lawrence, 1860)	XAHU
yellow rail			Coturnicops noveboracensis (Gmelin, 1789)	YEAR
yellow bittern		Ixobrychus sinensis (Gmelin, 1789)		YEBI
yellow warbler		Setophaga aestiva (J.F.Gmelin, 1789)	YEWA
yellow-bellied sapsucker	Sphyrapicus varius (Linnaeus, 1766)	YBSA
yellow-billed cuckoo		Coccyzus americanus (Linnaeus, 1758)	YBCU
yellow-billed loon		Gavia adamsii�(G.R.Gray, 1859)		YBLO
yellow-billed magpie		Pica nuttalli (Audubon, 1837)		YBMA
yellow-breasted chat		Icteria virens (Linnaeus, 1758)		YBCH
yellow-crowned night-heron	Nyctanassa violacea (Linnaeus, 1758)	YCNH
yellow-eyed junco		Junco phaeonotus Wagler, 1831		YEJU
yellow-footed gull		Larus livens Dwight, 1919		YFGU
yellow-green vireo		Vireo flavoviridis (Cassin, 1851)		YGVI
yellow-headed blackbird	Xanthocephalus xanthocephalus (Bonaparte, 1826) YHBL
yellow-legged gull		Larus michahellis J.F.Naumann, 1840	YLGU
yellow-nosed albatross		Thalassarche chlororhynchos (Gmelin, 1789)	YNAL
yellow-rumped warbler		Setophaga coronata�(Linnaeus, 1766)	YRWA
yellow-throated vireo		Vireo flavifrons Vieillot, 1808		YTVI
yellow-throated warbler	Setophaga dominica (Linnaeus, 1766)	YTWA
yucatan vireo		Vireo magister (S.F.Baird, 1871)		YUVI
zenaida dove		Zenaida aurita (Temminck, 1809)		ZEDO
zone-tailed hawk		Buteo albonotatus Kaup, 1847		ZTHA